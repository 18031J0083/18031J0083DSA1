

import java.util.Scanner;

public class Solution {
public static void main(String[] args)
{
	Probing p=new Probing();
	Scanner sc=new Scanner(System.in);
	int s=sc.nextInt();
	int c=0;
	while(sc.hasNext())
	{
		
	    String q=sc.nextLine();
	    //System.out.println(q);
	    String a[]=q.split(" ");
		switch(a[0])
		{
		case "put":
			p.put(a[1],Integer.parseInt(a[2]) );
			break;
		case "get":
			
			if( p.get(a[1])==null)
			{
				System.out.println("null");
			}
			else
			{
			System.out.println("{"+a[1]+":"+p.get(a[1])+"}");
			}
			break;
		case "delete":
			p.delete(a[1]);
			break;
		case "display":
			p.display();
			break;
		}
		c++;
	}
}
}
