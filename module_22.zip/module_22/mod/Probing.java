

public class Probing<Key,Value> {
int n=0;
int m=30001;
Value[] val=(Value[]) new Object[m];
Key[] keys=(Key[]) new Object[m];
int hash(Key k)
{
	 return k.hashCode() ;
}
void put(Key k,Value v)
{
int i;
for(i=hash(k);keys[i]!=null;i=(i+1)%m)
{
	if(keys[i].equals(k))
	{
	val[i]=v;
	return;
	}
}
    keys[i]=k;
	val[i]=v;
	n++;
}
public int size() {
    return n;
}
public Value get(Key k)
{
	for(int i=hash(k);keys[i]!=null;i=(i+1)%m)
	
		if(k.equals(keys[i]))
			return val[i];
	
	
	return null;
}
public void delete(Key k)
{
	int i=hash(k);
	while(!k.equals(keys))
		i=(i+1)%m;
	keys[i]=null;
	val[i]=null;
	i=(i+1)%m;
	while(keys[i]!=null)
	{
		Key a=keys[i];
		Value b=val[i];
		keys[i]=null;
		val[i]=null;
		n--;
		put(a,b);
		i=(i+1)%m;
	}
	n--;
	if(n>0&&n<=m/8)
		resize(m/2);
	
	
}
private void resize(int c) {
    Probing<Key, Value> temp = new Probing<Key, Value>();

	 for (int i = 0; i < m; i++) {
         if (keys[i] != null) {
             temp.put(keys[i], val[i]);
         }
     }
     keys = temp.keys;
     val= temp.val;
     m    = temp.m;
	
}
void display()
{
for(int i=0;i<m;i++)
{
    if(val!=null)
	System.out.println("{"+keys[i]+":"+val+"}");
}
}
}
